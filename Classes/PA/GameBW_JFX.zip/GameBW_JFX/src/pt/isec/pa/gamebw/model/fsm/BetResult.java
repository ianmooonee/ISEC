package pt.isec.pa.gamebw.model.fsm;

public enum BetResult {
    WON,LOST,ERROR
}
