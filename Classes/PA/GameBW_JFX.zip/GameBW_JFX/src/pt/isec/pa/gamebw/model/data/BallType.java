package pt.isec.pa.gamebw.model.data;

public enum BallType {
    BLACK, WHITE, NONE
}
