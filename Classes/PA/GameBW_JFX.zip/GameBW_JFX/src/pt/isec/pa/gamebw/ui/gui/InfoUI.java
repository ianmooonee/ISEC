package pt.isec.pa.gamebw.ui.gui;

import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import pt.isec.pa.gamebw.model.GameBWManager;
public class InfoUI extends BorderPane {
    GameBWManager gameBWManager;
    Button btnStart, btnExit;
    Label lbWBWon, lbWBOut, lbBBOut;

    public InfoUI(GameBWManager gameBWManager){
        this.gameBWManager=gameBWManager;

        createViews();
        registerHandlers();
        update();
    }

    private void update() {
    }

    private void registerHandlers() {

    }

    private void createViews() {

    }
}
