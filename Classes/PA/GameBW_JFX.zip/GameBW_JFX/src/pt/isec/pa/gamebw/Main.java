package pt.isec.pa.gamebw;

import javafx.application.Application;
import pt.isec.pa.gamebw.ui.gui.MainJFX;

public class Main {
    public static void main(String[] args) {
        Application.launch(MainJFX.class,args);
    }
}