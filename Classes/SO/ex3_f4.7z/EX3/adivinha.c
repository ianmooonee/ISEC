#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>
#include <stdlib.h>


void resposta(int sig, siginfo_t *info, void *secret){
    printf(" valor %d", info->si_value.sival_int);
    int val =info->si_value.sival_int;

    if (val == 0){
            printf("Acertou o numero");
    } else if (val == 1){
            printf("Numero enviado é maio");
    }else if (val == 2 ){
            printf("Numero enviado é menor");
    }
}
 
int main(int argc, char **argv){
 
    //signal(SIGALRM,sig_handler); // Register signal handler

    struct sigaction sa;
    sa.sa_sigaction = resposta;
    sa.sa_flags = SA_RESTART|SA_SIGINFO; 
    sigaction(SIGUSR1, &sa, NULL);

    

        int num;

        while (1)
        {
            printf("\nSoma:");
            scanf("%d", &num);
            union sigval valores;
            sigqueue(atoi(argv[1]),SIGUSR1,valores);
        }


    return 0;
}
