#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>
#include <stdlib.h>

//sorteia &

int numSort;
int numeroCertos = 0;

void sorteiNumeros(){
    srand(time(NULL));
    numSort = rand() % 100 + 1;
}

void sair(int signum){
    printf("Chegou um sinal %d e acertou %d vezes",signum,numeroCertos);
    exit(1);
}

void jogo(int signum, siginfo_t *info, void *secret){
    
    
    printf(" valor %d", info->si_value.sival_int);
    int val =info->si_value.sival_int;
    int aux;
    if (val == numSort){
            numeroCertos++;
            sorteiNumeros();
            printf("Acertou o numero");
            aux =0;
    } else if (val > numSort){
        aux = 1;
            printf("Numero enviado é maio");
    }else if (val < numSort){
        aux =2;
            printf("Numero enviado é menor");
    }


    union sigval val2;
    val2.sival_int = aux;
    sigqueue (info->si_pid,SIGUSR1,val2);
}

 
int main(){
 
/*
    int i = fork ();
    if (i >0 )
        return 1;
    */

    //signal(SIGALRM,sig_handler); // Register signal handler

    setbuf(stdout, NULL);

    int pid = getpid();
    printf("PID: %d", pid);

    struct sigaction sa;
    sa.sa_sigaction = jogo;
    sa.sa_flags = SA_RESTART|SA_SIGINFO; 
    sigaction(SIGUSR1,&sa,NULL);


    struct sigaction sa2;
    sa2.sa_handler = sair;
    sa2.sa_flags = SA_RESTART|SA_SIGINFO; 
    sigaction(SIGINT,&sa2,NULL);


   sorteiNumeros();

    do{      

    }while (1);
   return 0;
}
